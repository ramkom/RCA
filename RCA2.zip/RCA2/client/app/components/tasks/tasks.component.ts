import { Component } from '@angular/core';
import {TaskService} from '../../services/task.service';
import {RCA} from '../../../RCA';

@Component({
  moduleId: module.id,
  selector: 'tasks',
  templateUrl: 'tasks.component.html'
})

export class TasksComponent { 
    tasks: RCA[];
    appName: string;
    technology: string;
    title: string;
    probDesc: string;
    probDet: string;
    solution: string;
    
    constructor(private taskService:TaskService){
        this.taskService.getTasks()
            .subscribe(tasks => {
                this.tasks = tasks;
            });
    }
    
    addTask(event){
        event.preventDefault();
        var newTask = {
            appName: this.appName,
            technology: this.technology,
            title: this.title,
            probDesc: this.probDesc,
            probDet: this.probDet,
            solution: this.solution
        }
        
        this.taskService.addTask(newTask)
            .subscribe(task => {
                 this.tasks.push(task);
                  console.log("values pushed in TS");
                this.appName = '';
                this.technology = '';
                this.title = '';
                this.probDesc = '';
                this.probDet = '';
                this.solution = '';
                document.forms[0].reset();
                console.log("values pushed in TS");
                
            });
    }
    
    deleteTask(id){
        var tasks = this.tasks;
        
        this.taskService.deleteTask(id).subscribe(data => {
            if(data.n == 1){
                for(var i = 0;i < tasks.length;i++){
                    if(tasks[i]._id == id){
                        tasks.splice(i, 1);
                    }
                }
            }
        });
    }
    
    updateStatus(task){
        var _task = {
            _id:task._id,
            appName: task.appName,
            technology: task.technology,
            title: task.title,
            probDesc: task.probDesc,
            probDet: task.probDet,
            solution: task.solution
        };
        
        this.taskService.updateStatus(_task).subscribe(data => {
            
        });
    }
}
