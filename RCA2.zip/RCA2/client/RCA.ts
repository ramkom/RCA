export class RCA{
    _id: string;
    appName: string;
    technology: string;
    title: string;
    probDesc: string;
    probDet: string;
    solution: string;
}