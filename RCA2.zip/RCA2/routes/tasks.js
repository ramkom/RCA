var express = require('express');
var router = express.Router();
var mongojs = require('mongojs');
var db = mongojs('mongodb://localhost:27017/knowledgebase', ['rca']);

// Get All Tasks
router.get('/tasks', function(req, res, next){
    db.rca.find(function(err, tasks){
        if(err){
            res.send(err);
        }
        res.json(tasks);
    });
});

// Get Single Task
router.get('/task/:id', function(req, res, next){
    db.rca.findOne({_id: mongojs.ObjectId(req.params.id)}, function(err, task){
        if(err){
            res.send(err);
        }
        res.json(task);
    });
});

//Save Task
router.post('/task', function(req, res, next){
    var task = req.body;
    if(!task.title){
        res.status(400);
        res.json({
            "error": "Bad Data"
        });
    } else {
        db.rca.save(task, function(err, task){
            if(err){
                res.send(err);
            }
            res.json(task);
            console.log("data saved");
        });
    }
});

// Delete Task
router.delete('/task/:id', function(req, res, next){
    db.rca.remove({_id: mongojs.ObjectId(req.params.id)}, function(err, task){
        if(err){
            res.send(err);
        }
        res.json(task);
    });
});

// Update Task
router.put('/rca/:id', function(req, res, next){
    var task = req.body;
    var updTask = {};
    
   /* if(task.isDone){
        updTask.isDone = rca.isDone;
    }
    */
    if(task.appName){
        updTask.title = task.title;
    }
    
    if(!updTask){
        res.status(400);
        res.json({
            "error":"Bad Data"
        });
    } else {
        db.rca.update({_id: mongojs.ObjectId(req.params.id)},updTask, {}, function(err, task){
        if(err){
            res.send(err);
        }
        res.json(task);
    });
    }
});

module.exports = router;